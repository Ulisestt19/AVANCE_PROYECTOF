<?php
const BASE_URL = "http://localhost/Tienda-softec/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "tienda-softec";
const CHARSET = "charset=utf8";
const TITLE = "SHOP";
const MONEDA = "USD";
const CLIENT_ID = "";
?>